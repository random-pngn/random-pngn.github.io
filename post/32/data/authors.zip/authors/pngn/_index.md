---
# folder名がauthorです
name: pngn
# [必須] 表示名 folder名と合わせとく方が間違えないかも

authors:
- pngn
# [必須] folder名を書く これをミスると部員紹介ページがバグる

organizations:
- name: 情報工学課程2回 # 所属名
  url: ""

bio: 情報2回 競プロやアプリ開発が趣味です。
# [必須] short bio  blogの下や部員紹介ページで表示

interests: # 興味がある分野 書かないとデザイン的にアンバランスになるけどいらないよなぁ
- 競技プログラミング
- flutter

social: # SNS 不要なら削除
- icon: twitter
  icon_pack: fab
  link: https://twitter.com/4pngn

- icon: github
  icon_pack: fab
  link: https://github.com/random-pngn/

- icon: envelope # メール
  icon_pack: fas
  link: 'mailto:kada.random@gmail.com'  # For a direct email link, use "mailto:test@example.org".

# [必須] ↓ 自己紹介(長文) bioと同じでいいよ
---
普段は競プロ(C++)をしてます。AtCoderのIDは[pngn](https://atcoder.jp/users/pngn)です。青と黄色の間を行ったり来たりしています。  
最近は趣味でflutterでアプリ開発したり、Hugoをいじってます。  
好きなOSはUbuntu!好きなシェルはzsh!好きなエディタはVimです!  
